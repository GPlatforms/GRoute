package main

import (
	"company/vpngo/admin/controllers"
	"company/vpngo/admin/models"

	"github.com/gin-gonic/gin"
)

var (
	adminController      = &controllers.AdminController{}
	configInfoController = &controllers.ConfigInfoController{}
)

func main() {
	models.InitConfig()

	gin.SetMode(gin.ReleaseMode)
	router := gin.New()
	router.Use(gin.Recovery())
	if models.Config.Mode != "prod" {
		router.Use(gin.Logger())
	}

	router.LoadHTMLGlob("web/*")

	router.GET("/admins", adminController.AdminLoginHtml)

	noAuth := router.Group("/api/v1/admin")
	{

		noAuth.POST("/login", adminController.AdminLogin)
	}

	auth := router.Group("/api/v1/admin")
	auth.Use(controllers.AuthRequired)
	{
		auth.GET("/config", configInfoController.GetConfigInfoList)
		auth.POST("/config", configInfoController.AddConfigInfo)
		auth.PATCH("/config", configInfoController.UpdateConfigInfo)
		auth.DELETE("/config", configInfoController.DeleteConfigInfo)
	}

	router.Static("/admin", "./web")

	err := router.Run(":" + models.Config.Port)
	if err != nil {
		panic(err)
	}
}
