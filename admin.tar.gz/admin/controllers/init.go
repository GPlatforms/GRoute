package controllers

import (
	"errors"

	"company/vpngo/admin/common"
	"company/vpngo/admin/models"

	"github.com/gin-gonic/gin"
)

var Username string

func AuthRequired(c *gin.Context) {
	token := c.Request.Header.Get("Authorization")
	if token == "" {
		models.CommonResult(c, models.UnauthorizedErr)
		c.Abort()
		return
	}

	err := CheckToken(token)
	if err != nil {
		models.CommonResult(c, models.UnauthorizedErr)
		c.Abort()
		return
	}
}

func CheckToken(token string) error {
	t, err := common.ParseJWT(models.PriKey, token)
	if err != nil {
		return err
	}
	claims, ok := t.Claims.(*common.MyCustomClaims)
	if !ok || !t.Valid {
		return errors.New("Unauthorized")
	}

	if claims.Username == "" {
		return errors.New("Unauthorized")
	}

	Username = claims.Username
	return nil
}
